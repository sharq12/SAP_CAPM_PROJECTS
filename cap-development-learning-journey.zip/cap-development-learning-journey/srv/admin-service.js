const cds = require('@sap/cds');

class AdminService extends cds.ApplicationService{
    init(){
        const { Authors, Books, POinvoiceHeader, POInvoiceItems, ShippingAddress, BillingAddress} = this.entities;
        this.before(['CREATE', 'UPDATE'], Authors, this.validateLifeData);
        this.on('createAuthorBooks', this.insertAuthorBooks);
        this.on('createPO',this.insertPOData);
        return super.init();
    }
    validateLifeData(req){
        const { dateOfBirth, dateOfDeath } = req.data;
        if(!dateOfBirth || !dateOfDeath){
            return;
        }
        const birth = new Date(dateOfBirth);
        const death = new Date(dateOfDeath);
        if(death < birth ){
            req.error(`The date of death ${death} is before the date of birth ${birth}`);
        }
    }
    async insertAuthorBooks(req){
        const {Authors, Books} = this.entities;
        if(!req.data){
            return req.error(`payload send is not correct`)
        }
        const payload = JSON.parse(req.data.strValue).payload;
        let paylaodHeader = [];
        let payloadItems = [];
        payload.forEach((ele)=>{
            let headerObj ={
                "ID": ele["ID"],
                "name": ele["name"],
                "dateOfBirth": ele["dateOfBirth"],
                "dateOfDeath": ele["dateOfDeath"],
                "modifiedAt": new Date().toISOString(),
                "modifiedBy": "SRS",
                "createdAt": new Date().toISOString(),
                "createdBy": "SRS"
            }
            if(ele["books"].length !== 0){
            ele["books"].forEach((itm)=>{
                let itemObj = {
                    "ID": itm["ID"],
                    "title": itm["title"],
                    "author_ID": itm["author_ID"],
                    "genre": itm["genre"],
                    "publCountry":itm["publCountry"],
                    "stock": itm["stock"],
                    "price_amount":itm["price_amount"],
                    "price_currency":itm["price_currency"],
                    "isHardcover": itm["isHardcover"],
                    "modifiedAt": new Date().toISOString(),
                    "modifiedBy": "SRS",
                    "createdAt": new Date().toISOString(),
                    "createdBy": "SRS"
            }
            payloadItems = [...payloadItems,  itemObj];
            })
        }
            paylaodHeader = [...paylaodHeader, headerObj];
        }) 
        
        // await INSERT.into (Authors) .entries (
        //     paylaodHeader[0]
        //  )
        
        const authorsCreatedInfo = await INSERT(paylaodHeader).into(Authors);
        const booksCreatedInfo =  await INSERT(payloadItems).into(Books);
        console.log(payload);
        console.log(paylaodHeader);
        console.log(payloadItems);
        return { authors : `$ authors: ${authorsCreatedInfo}, books: ${booksCreatedInfo}` }
         
    }
    async insertPOData(req){
        const {POinvoiceHeader,POInvoiceItems,BillingAddress,ShippingAddress} = this.entities;
        if(!req.data){
            return req.error(`payload send is not correct`);
        }
        const payload = JSON.parse(req.data.payload).PoMetaData;
        let poHeaderArr = [];
        let poItemsArr=[];
        let shippingAddressArr = [];
        let billingAddressArr = [];

        payload.forEach((header)=>{
            let poHeaderObj = {
                "ID":header["uuid"],
                "poID":header["po_id"],
                "caseID":header["case_id"],
                "runDate":header["run_date"],
                "poNumber":header["po_number"][0],
                "email":header["email"][0],
                "email_cc":header["email_cc"][0],
                "webRefNumber":header["web_ref_number"][0],
                "contractNumber":header["contract_number"][0],
                "tpi_provider":header["tpi"]["provider"][0],
                "tpi_name2":header["tpi"]["name2"][0],
                "poTotal":header["po_total"][0],
                "overallAccuracy":header["overall_accuracy"]
            }
            poHeaderArr = [...poHeaderArr,poHeaderObj];

            if(header["items"].length > 0){
                
                header["items"].forEach((item)=>{
                    let poItemObj = {
                   "partNumber":  item["partnumber"][0],  
                   "quantity": item["quantity"][0],  
                   "unitPrice": item["unit_price"][0] ,
                   "extPrice":item["extended_price"][0] ,
                   "header_ID": header["uuid"] 
                    }; 

                    poItemsArr = [...poItemsArr, poItemObj];
                })
            }
            if(header["shipping_address"]){
                let shippingAddressObj = {
                    "name1":header["shipping_address"]["name1"][0],
                    "name2":header["shipping_address"]["name2"][0],
                    "street":header["shipping_address"]["street"][0],
                    "city":header["shipping_address"]["city"][0],
                    "district":header["shipping_address"]["district"][0],
                    "state":header["shipping_address"]["state"][0],
                    "zipcode":header["shipping_address"]["zipcode"][0],
                    "country":header["shipping_address"]["country"][0],
                    "header_ID":header["uuid"]
                }
            shippingAddressArr = [...shippingAddressArr, shippingAddressObj] ;
            }

          if(header["billing_address"]){
            let billingAddressObj = {
                "custID":header["billing_address"]["cust_id"][0],
                "name1":header["billing_address"]["name1"][0],
                "name2":header["billing_address"]["name2"][0],
                "street":header["billing_address"]["street"][0],
                "city":header["billing_address"]["city"][0],
                "district":header["billing_address"]["district"][0],
                "state":header["billing_address"]["state"][0],
                "zipcode":header["billing_address"]["zipcode"][0],
                "country":header["billing_address"]["country"][0],
                "header_ID":header["uuid"]
                }
                billingAddressArr = [...billingAddressArr, billingAddressObj];
          }
        })
        const poHeaderCreatedInfo = await INSERT(poHeaderArr).into(POinvoiceHeader);
        const poItemsCreatedInfo =  await INSERT(poItemsArr).into(POInvoiceItems);
        const shipppingAddressCreatedInfo = await INSERT(shippingAddressArr).into(ShippingAddress);
        const billingAddressCreatedInfo = await INSERT(billingAddressArr).into(BillingAddress);
        console.log(payload);
        
        return { po : ` header: ${poHeaderCreatedInfo.results}, items:  ${poItemsCreatedInfo.results}, BillingAddress: ${billingAddressCreatedInfo.results}, ShippingAddress: ${shipppingAddressCreatedInfo.results}` };

    }
}

module.exports = AdminService;