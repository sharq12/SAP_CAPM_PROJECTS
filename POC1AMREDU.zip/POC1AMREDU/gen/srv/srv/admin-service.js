const cds = require('@sap/cds');

class AdminService extends cds.ApplicationService{
    init(){
        const {POinvoiceHeader, POInvoiceItems, ShippingAddress, BillingAddress} = this.entities;
        this.on('createPO',this.insertPOData);
        return super.init();
    }
    async insertPOData(req){
        const {POinvoiceHeader,POInvoiceItems,BillingAddress,ShippingAddress} = this.entities;
        if(!req.data){
            return req.error(`payload send is not correct`);
        }
        const payload = JSON.parse(req.data.payload).PoMetaData;
        let poHeaderArr = [];
        let poItemsArr=[];
        let shippingAddressArr = [];
        let billingAddressArr = [];

        payload.forEach((header)=>{
            let poHeaderObj = {
                "ID":header["uuid"],
                "poID":header["po_id"],
                "caseID":header["case_id"],
                "runDate":header["run_date"],
                "poNumber":header["po_number"][0],
                "email":header["email"][0],
                "email_cc":header["email_cc"][0],
                "webRefNumber":header["web_ref_number"][0],
                "contractNumber":header["contract_number"][0],
                "tpi_provider":header["tpi"]["provider"][0],
                "tpi_name2":header["tpi"]["name2"][0],
                "poTotal":header["po_total"][0],
                "overallAccuracy":header["overall_accuracy"]
            }
            poHeaderArr = [...poHeaderArr,poHeaderObj];

            if(header["items"].length > 0){
                
                header["items"].forEach((item)=>{
                    let poItemObj = {
                   "partNumber":  item["partnumber"][0],  
                   "quantity": item["quantity"][0],  
                   "unitPrice": item["unit_price"][0] ,
                   "extPrice":item["extended_price"][0] ,
                   "header_ID": header["uuid"] 
                    }; 

                    poItemsArr = [...poItemsArr, poItemObj];
                })
            }
            if(header["shipping_address"]){
                let shippingAddressObj = {
                    "name1":header["shipping_address"]["name1"][0],
                    "name2":header["shipping_address"]["name2"][0],
                    "street":header["shipping_address"]["street"][0],
                    "city":header["shipping_address"]["city"][0],
                    "district":header["shipping_address"]["district"][0],
                    "state":header["shipping_address"]["state"][0],
                    "zipcode":header["shipping_address"]["zipcode"][0],
                    "country":header["shipping_address"]["country"][0],
                    "header_ID":header["uuid"]
                }
            shippingAddressArr = [...shippingAddressArr, shippingAddressObj] ;
            }

          if(header["billing_address"]){
            let billingAddressObj = {
                "custID":header["billing_address"]["cust_id"][0],
                "name1":header["billing_address"]["name1"][0],
                "name2":header["billing_address"]["name2"][0],
                "street":header["billing_address"]["street"][0],
                "city":header["billing_address"]["city"][0],
                "district":header["billing_address"]["district"][0],
                "state":header["billing_address"]["state"][0],
                "zipcode":header["billing_address"]["zipcode"][0],
                "country":header["billing_address"]["country"][0],
                "header_ID":header["uuid"]
                }
                billingAddressArr = [...billingAddressArr, billingAddressObj];
          }
        })
        const poHeaderCreatedInfo = await INSERT(poHeaderArr).into(POinvoiceHeader);
        const poItemsCreatedInfo =  await INSERT(poItemsArr).into(POInvoiceItems);
        const shipppingAddressCreatedInfo = await INSERT(shippingAddressArr).into(ShippingAddress);
        const billingAddressCreatedInfo = await INSERT(billingAddressArr).into(BillingAddress);
        console.log(payload);
        
        return { po : ` header: ${poHeaderCreatedInfo.results}, items:  ${poItemsCreatedInfo.results}, BillingAddress: ${billingAddressCreatedInfo.results}, ShippingAddress: ${shipppingAddressCreatedInfo.results}` };

    }
}

module.exports = AdminService;